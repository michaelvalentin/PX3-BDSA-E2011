-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 30. 11 2011 kl. 16:47:48
-- Serverversion: 5.0.51
-- PHP-version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `px3`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `action`
--

CREATE TABLE IF NOT EXISTS `action` (
  `id` int(11) NOT NULL,
  `label` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `action`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `person_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  PRIMARY KEY  (`person_id`,`action_id`),
  KEY `Person_Action_Action1` (`action_id`),
  KEY `Person_Action_Person1` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `permission`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  `address` text,
  `cpr` int(11) NOT NULL,
  `eligible_to_vote` tinyint(1) NOT NULL,
  `has_voted` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `person`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `quiz`
--

CREATE TABLE IF NOT EXISTS `quiz` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `quiz_person1` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `quiz`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `raw_data`
--

CREATE TABLE IF NOT EXISTS `raw_data` (
  `cpr` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mother_cpr` int(11) default NULL,
  `father_cpr` int(11) default NULL,
  `address` text,
  `last_address` text,
  PRIMARY KEY  (`cpr`),
  KEY `raw_data_raw_data` (`mother_cpr`),
  KEY `raw_data_raw_data1` (`father_cpr`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `raw_data`
--


-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `voter_card`
--

CREATE TABLE IF NOT EXISTS `voter_card` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `valid` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `voter_card_Person1` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `voter_card`
--


--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `permission`
--
ALTER TABLE `permission`
  ADD CONSTRAINT `Person_Action_Person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Person_Action_Action1` FOREIGN KEY (`action_id`) REFERENCES `action` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `raw_data`
--
ALTER TABLE `raw_data`
  ADD CONSTRAINT `raw_data_raw_data` FOREIGN KEY (`mother_cpr`) REFERENCES `raw_data` (`cpr`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `raw_data_raw_data1` FOREIGN KEY (`father_cpr`) REFERENCES `raw_data` (`cpr`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Begrænsninger for tabel `voter_card`
--
ALTER TABLE `voter_card`
  ADD CONSTRAINT `voter_card_Person1` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
